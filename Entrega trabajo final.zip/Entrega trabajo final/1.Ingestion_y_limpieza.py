# Databricks notebook source
# MAGIC %md
# MAGIC ##Cargar los DataFrames de vuelos, aerolíneas y aeropuertos

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import (
    DateType,
    IntegerType,
    TimestampType
)

# Ruta donde se encuentran los archivos CSV
ruta = "/Volumes/analitica/data/landing/trabajo/"

# Cargar archivo de vuelos
df_flights = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("sep", ",") \
    .load(f"{ruta}/flights.csv")

# Cargar archivo de aerolíneas
df_airlines = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("sep", ",") \
    .load(f"{ruta}/airlines.csv")

# Cargar archivo de aeropuertos
df_airports = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("sep", ",") \
    .load(f"{ruta}/airports.csv")

# Visualizar los DataFrames
display(df_flights)
display(df_airlines)
display(df_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC Convertir los tipos de columnas correctamente

# COMMAND ----------

# Revisar estructura de los DataFrames
print("ESTRUCTURA DE VUELOS")
df_flights.printSchema()

print("ESTRUCTURA DE AEROLÍNEAS")
df_airlines.printSchema()

print("ESTRUCTURA DE AEROPUERTOS")
df_airports.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Realizamos las conversiones de tipo

# COMMAND ----------

# Convertir fecha de vuelo
df_flights = df_flights.withColumn(
    "flight_date",
    F.to_date(F.col("flight_date"))
)

# Convertir columnas de retrasos a enteros
columnas_delay = [
    "departure_delay",
    "arrival_delay",
    "dep_delay",
    "arr_delay"
]

for columna in columnas_delay:
    if columna in df_flights.columns:
        df_flights = df_flights.withColumn(
            columna,
            F.col(columna).cast(IntegerType())
        )

# COMMAND ----------

# MAGIC %md
# MAGIC Eliminar filas con campos nulos

# COMMAND ----------

df_flights = df_flights.dropna(
    subset=["flight_id", "airline_id", "origin_airport"]
)

# Verificar los resultados
print("Registros de vuelos después de eliminar nulos:",
      df_flights.count())

display(df_flights)

# COMMAND ----------

# MAGIC %md
# MAGIC Agregar columna de fecha y hora de ingestión

# COMMAND ----------

# Agregar timestamp de ingestión
df_flights = df_flights.withColumn(
    "ingest_timestamp",
    F.current_timestamp()
)

df_airlines = df_airlines.withColumn(
    "ingest_timestamp",
    F.current_timestamp()
)

df_airports = df_airports.withColumn(
    "ingest_timestamp",
    F.current_timestamp()
)

# Visualizar resultados
display(df_flights)
display(df_airlines)
display(df_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Guardar los DataFrames en Delta Lake – Capa Bronze

# COMMAND ----------

# Crear esquema Bronze
spark.sql("""
CREATE SCHEMA IF NOT EXISTS analitica.bronze
""")

# Guardar vuelos
df_flights.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("analitica.bronze.flights")

# Guardar aerolíneas
df_airlines.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("analitica.bronze.airlines")

# Guardar aeropuertos
df_airports.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("analitica.bronze.airports")

print("¡Datos almacenados correctamente en Delta Lake!")

# COMMAND ----------

# MAGIC %md
# MAGIC Verificacion datos almacenados 

# COMMAND ----------

# Consultar las tablas Bronze
display(spark.table("analitica.bronze.flights"))

display(spark.table("analitica.bronze.airlines"))

display(spark.table("analitica.bronze.airports"))