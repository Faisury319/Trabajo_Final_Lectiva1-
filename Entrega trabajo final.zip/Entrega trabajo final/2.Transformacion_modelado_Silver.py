# Databricks notebook source
# MAGIC %md
# MAGIC Cargar los dataframe de bronze 

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, DoubleType

# Cargar tablas Bronze
df_flights = spark.table("analitica.bronze.flights")
df_airlines = spark.table("analitica.bronze.airlines")
df_airports = spark.table("analitica.bronze.airports")

# Revisar esquemas
print("ESQUEMA DE VUELOS")
df_flights.printSchema()

print("ESQUEMA DE AEROLÍNEAS")
df_airlines.printSchema()

print("ESQUEMA DE AEROPUERTOS")
df_airports.printSchema()

# Visualizar información
display(df_flights)
display(df_airlines)
display(df_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC Unir las tablas para enriquecer los vuelos

# COMMAND ----------

# Función para identificar columnas disponibles
def buscar_columna(df, opciones):
    for columna in opciones:
        if columna in df.columns:
            return columna
    raise ValueError(
        f"No se encontró ninguna de estas columnas: {opciones}. "
        f"Columnas disponibles: {df.columns}"
    )

# Identificar columnas de vuelos
col_airline = buscar_columna(
    df_flights,
    ["airline_id"]
)

col_origin = buscar_columna(
    df_flights,
    ["origin_airport"]
)

col_destination = buscar_columna(
    df_flights,
    ["dest_airport", "destination_airport"]
)

# Identificar columnas de aerolíneas
col_airline_key = buscar_columna(
    df_airlines,
    ["airline_id"]
)

col_airline_name = buscar_columna(
    df_airlines,
    ["airline_name", "name", "airline"]
)

# Identificar identificador del aeropuerto
col_airport_key = buscar_columna(
    df_airports,
    ["airport_id", "airport_code", "iata_code", "code", "airport"]
)

col_city = buscar_columna(
    df_airports,
    ["city", "airport_city"]
)

col_country = buscar_columna(
    df_airports,
    ["country", "airport_country"]
)

print("Columnas identificadas correctamente")

# COMMAND ----------

# MAGIC %md
# MAGIC Ahora preparamos la información de las aerolíneas y los aeropuertos

# COMMAND ----------

# Preparar tabla de aerolíneas
df_airlines_clean = df_airlines.select(
    F.col(col_airline_key).alias("airline_id"),
    F.col(col_airline_name).alias("airline_name")
)

# Preparar tabla de aeropuertos
df_airports_clean = df_airports.select(
    F.col(col_airport_key).alias("airport_key"),
    F.col(col_city).alias("airport_city"),
    F.col(col_country).alias("airport_country")
)

# Unir vuelos con aerolíneas
df_silver = df_flights.join(
    df_airlines_clean,
    df_flights[col_airline] == df_airlines_clean["airline_id"],
    "left"
).drop(df_airlines_clean["airline_id"])

# Unir con aeropuerto de origen
df_silver = df_silver.join(
    df_airports_clean.alias("origin"),
    F.col(col_origin) == F.col("origin.airport_key"),
    "left"
).withColumn(
    "origin_city",
    F.col("origin.airport_city")
).withColumn(
    "origin_country",
    F.col("origin.airport_country")
).drop(
    "airport_key",
    "airport_city",
    "airport_country"
)

# Unir con aeropuerto de destino
df_silver = df_silver.join(
    df_airports_clean.alias("destination"),
    F.col(col_destination) == F.col("destination.airport_key"),
    "left"
).withColumn(
    "destination_city",
    F.col("destination.airport_city")
).withColumn(
    "destination_country",
    F.col("destination.airport_country")
).drop(
    "airport_key",
    "airport_city",
    "airport_country"
)

# Visualizar vuelos enriquecidos
display(df_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC Crear nuevas columnas e indicadores

# COMMAND ----------

# Identificar columnas de retrasos
col_dep_delay = buscar_columna(
    df_silver,
    ["dep_delay", "departure_delay"]
)

col_arr_delay = buscar_columna(
    df_silver,
    ["arr_delay", "arrival_delay"]
)

# Identificar distancia en millas
col_distance = buscar_columna(
    df_silver,
    ["distance", "distance_miles"]
)

# Convertir tipos numéricos
df_silver = df_silver.withColumn(
    col_dep_delay,
    F.col(col_dep_delay).cast(IntegerType())
).withColumn(
    col_arr_delay,
    F.col(col_arr_delay).cast(IntegerType())
).withColumn(
    col_distance,
    F.col(col_distance).cast(DoubleType())
)

# COMMAND ----------

# MAGIC %md
# MAGIC Crear delay_total

# COMMAND ----------

df_silver = df_silver.withColumn(
    "delay_total",
    F.when(
        F.col(col_dep_delay).isNotNull() &
        F.col(col_arr_delay).isNotNull(),
        F.col(col_dep_delay) + F.col(col_arr_delay)
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC Crear on_time

# COMMAND ----------

df_silver = df_silver.withColumn(
    "on_time",
    F.when(
        F.col(col_arr_delay).isNull(),
        None
    ).when(
        F.col(col_arr_delay) <= 15,
        True
    ).otherwise(False)
)

# COMMAND ----------

# MAGIC %md
# MAGIC Crear distance_km

# COMMAND ----------

df_silver = df_silver.withColumn(
    "distance_km",
    F.round(F.col(col_distance) * 1.60934, 2)
)

# COMMAND ----------

# MAGIC %md
# MAGIC Crear delay_category

# COMMAND ----------

df_silver = df_silver.withColumn(
    "delay_category",
    F.when(F.col("delay_total").isNull(), None)
    .when(F.col("delay_total") <= 0, "None")
    .when(F.col("delay_total") <= 15, "Short")
    .when(F.col("delay_total") <= 60, "Medium")
    .otherwise("Long")
)

# Visualizar nuevas columnas
display(df_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Agregaciones por aerolínea

# COMMAND ----------

# MAGIC %md
# MAGIC Retraso promedio por aerolinea, distancia total recorrida en kms y numero de vuelos 

# COMMAND ----------

# Métricas generales por aerolínea
df_airline_metrics = df_silver.groupBy(
    "airline_id",
    "airline_name"
).agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay"),
    F.round(F.sum("distance_km"), 2).alias("total_distance_km"),
    F.count("flight_id").alias("total_flights"),
    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("on_time_percentage")
)

display(df_airline_metrics)

# COMMAND ----------

# MAGIC %md
# MAGIC Porcentaje de vuelos a tiempo por aerolinea y aeropuerto de origen 

# COMMAND ----------

df_airline_origin_metrics = df_silver.groupBy(
    "airline_id",
    "airline_name",
    "origin_airport"
).agg(
    F.count("flight_id").alias("total_flights"),
    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("on_time_percentage")
)

display(df_airline_origin_metrics)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Agregaciones por aeropuerto

# COMMAND ----------

# MAGIC %md
# MAGIC Métricas de vuelos salientes

# COMMAND ----------

df_airport_origin_metrics = df_silver.groupBy(
    "origin_airport"
).agg(
    F.round(F.avg("delay_total"), 2).alias("avg_departure_delay"),
    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("on_time_percentage"),
    F.count("flight_id").alias("outgoing_flights")
)

display(df_airport_origin_metrics)

# COMMAND ----------

# MAGIC %md
# MAGIC Métricas de vuelos entrantes

# COMMAND ----------

df_airport_destination_metrics = df_silver.groupBy(
    col_destination
).agg(
    F.round(F.avg("delay_total"), 2).alias("avg_arrival_delay"),
    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("on_time_percentage"),
    F.count("flight_id").alias("incoming_flights")
)

display(df_airport_destination_metrics)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Validación y limpieza final

# COMMAND ----------

# MAGIC %md
# MAGIC Revisar valores nulos

# COMMAND ----------

# Función para contar valores nulos
def revisar_nulos(df, nombre):
    print(f"Valores nulos en {nombre}")

    df.select([
        F.count(
            F.when(F.col(c).isNull(), c)
        ).alias(c)
        for c in df.columns
    ]).show(truncate=False)

# Revisar tablas
revisar_nulos(df_silver, "VUELOS SILVER")
revisar_nulos(df_airline_metrics, "MÉTRICAS AEROLÍNEAS")
revisar_nulos(df_airport_origin_metrics, "MÉTRICAS AEROPUERTOS")

# COMMAND ----------

# MAGIC %md
# MAGIC Reemplazar valores faltantes

# COMMAND ----------

df_silver = df_silver.fillna({
    "airline_name": "Unknown",
    "origin_city": "Unknown",
    "origin_country": "Unknown",
    "destination_city": "Unknown",
    "destination_country": "Unknown"
})

# Eliminar registros sin identificadores esenciales
df_silver = df_silver.dropna(
    subset=[
        "flight_id",
        "airline_id",
        "origin_airport",
        col_destination
    ]
)

# Verificar registros finales
print("Total de vuelos en Silver:", df_silver.count())

display(df_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC Guardar el DataFrame enriquecido en Silver

# COMMAND ----------

# Crear esquema Silver
spark.sql("""
CREATE SCHEMA IF NOT EXISTS analitica.silver
""")

# Guardar vuelos enriquecidos
df_silver.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.silver.flights_enriched")

# Guardar métricas por aerolínea
df_airline_metrics.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.silver.airline_metrics")

# Guardar métricas por aerolínea y aeropuerto de origen
df_airline_origin_metrics.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.silver.airline_origin_metrics")

# Guardar métricas de aeropuertos de salida
df_airport_origin_metrics.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.silver.airport_origin_metrics")

# Guardar métricas de aeropuertos de llegada
df_airport_destination_metrics.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.silver.airport_destination_metrics")

print("¡Transformaciones y almacenamiento Silver completados!")

# COMMAND ----------

# MAGIC %md
# MAGIC Verificacion de tablas almacenadas 

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES IN analitica.silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM analitica.silver.flights_enriched;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM analitica.silver.airline_metrics;