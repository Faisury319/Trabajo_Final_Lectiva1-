# Databricks notebook source
# MAGIC %md
# MAGIC ##Cargar los datos de Silver 

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Cargar información de Silver
df_silver = spark.table("analitica.silver.flights_enriched")

# Revisar estructura
df_silver.printSchema()

# Visualizar registros
display(df_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Análisis temporal de retrasos 

# COMMAND ----------

# MAGIC %md
# MAGIC Extraer mes, dias de la semana

# COMMAND ----------

# Crear columnas temporales
df_temporal = df_silver \
    .withColumn("month", F.month("flight_date")) \
    .withColumn("day_of_week", F.dayofweek("flight_date")) \
    .withColumn("quarter", F.quarter("flight_date"))

# Visualizar resultados
display(df_temporal.select(
    "flight_id",
    "flight_date",
    "month",
    "day_of_week",
    "quarter",
    "delay_total"
))

# COMMAND ----------

# MAGIC %md
# MAGIC Calcular promedio de retraso por mes

# COMMAND ----------

df_delay_month = df_temporal.groupBy(
    "month"
).agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay"),
    F.count("flight_id").alias("total_flights")
).orderBy("month")

display(df_delay_month)

# COMMAND ----------

# MAGIC %md
# MAGIC Calcular promedio de retraso por día de la semana

# COMMAND ----------

df_delay_weekday = df_temporal.groupBy(
    "day_of_week"
).agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay"),
    F.count("flight_id").alias("total_flights")
).orderBy("day_of_week")

display(df_delay_weekday)

# COMMAND ----------

# MAGIC %md
# MAGIC Calcular promedio de retraso por trimestre

# COMMAND ----------

df_delay_quarter = df_temporal.groupBy(
    "quarter"
).agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay"),
    F.count("flight_id").alias("total_flights")
).orderBy("quarter")

display(df_delay_quarter)

# COMMAND ----------

# MAGIC %md
# MAGIC Ranking de vuelos por retraso dentro de cada aerolínea

# COMMAND ----------

# Ventana para ordenar vuelos dentro de cada aerolínea
window_airline = Window.partitionBy(
    "airline_id"
).orderBy(
    F.col("delay_total").desc(),
    F.col("flight_id").asc()
)

# Crear ranking con row_number y dense_rank
df_ranking = df_silver.withColumn(
    "row_number",
    F.row_number().over(window_airline)
).withColumn(
    "dense_rank",
    F.dense_rank().over(
        Window.partitionBy("airline_id").orderBy(
            F.col("delay_total").desc()
        )
    )
)

display(df_ranking.select(
    "flight_id",
    "airline_id",
    "airline_name",
    "delay_total",
    "row_number",
    "dense_rank"
))

# COMMAND ----------

# MAGIC %md
# MAGIC Obtener los 5 vuelos con mayor retraso utilizando row_number

# COMMAND ----------

df_top5_row_number = df_ranking.filter(
    F.col("row_number") <= 5
).orderBy(
    "airline_id",
    "row_number"
)

display(df_top5_row_number)

# COMMAND ----------

# MAGIC %md
# MAGIC Obtener los 5 primeros puestos utilizando dense_rank

# COMMAND ----------

df_top5_dense_rank = df_ranking.filter(
    F.col("dense_rank") <= 5
).orderBy(
    "airline_id",
    "dense_rank"
)

display(df_top5_dense_rank)

# COMMAND ----------

# MAGIC %md
# MAGIC Analisis de diferencia 

# COMMAND ----------

# Comparar las posiciones de ambas funciones
df_analisis_diferencias = df_ranking.withColumn(
    "diferencia",
    F.col("row_number") - F.col("dense_rank")
).withColumn(
    "tipo_diferencia",
    F.when(
        F.col("row_number") == F.col("dense_rank"),
        "Sin diferencia"
    ).otherwise("Diferencia por empate")
)

# Mostrar resultados
display(
    df_analisis_diferencias.select(
        "flight_id",
        "airline_id",
        "airline_name",
        "delay_total",
        "row_number",
        "dense_rank",
        "diferencia",
        "tipo_diferencia"
    ).orderBy("airline_id", "row_number")
)

# COMMAND ----------

# Seleccionar vuelos del ranking row_number
df_row = df_top5_row_number.select(
    "flight_id",
    "airline_id",
    "airline_name",
    "delay_total",
    F.col("row_number").alias("posicion_row_number")
)

# Seleccionar vuelos del ranking dense_rank
df_dense = df_top5_dense_rank.select(
    "flight_id",
    "airline_id",
    F.col("dense_rank").alias("posicion_dense_rank")
)

# Comparar ambos resultados
df_comparacion_top5 = df_row.join(
    df_dense,
    on=["flight_id", "airline_id"],
    how="full_outer"
)

display(
    df_comparacion_top5.orderBy(
        "airline_id",
        "posicion_row_number"
    )
)

# COMMAND ----------

df_comparacion_top5 = df_comparacion_top5.withColumn(
    "resultado",
    F.when(
        F.col("posicion_row_number").isNull(),
        "Solo aparece en dense_rank"
    ).when(
        F.col("posicion_dense_rank").isNull(),
        "Solo aparece en row_number"
    ).when(
        F.col("posicion_row_number") == F.col("posicion_dense_rank"),
        "Misma posicion"
    ).otherwise(
        "Posicion diferente"
    )
)

display(
    df_comparacion_top5.orderBy(
        "airline_id",
        "posicion_row_number"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC Ranking de aeropuertos según promedio de retraso de vuelos salientes

# COMMAND ----------

# DBTITLE 1,Ranking aeropuertos por retraso de salida
# Identificar columna de retraso de salida
# (elige la primera opción presente en el esquema del DataFrame)
col_dep_delay = next(
    c for c in ["dep_delay", "departure_delay"]
    if c in df_silver.columns
)

# Calcular promedio de retraso por aeropuerto de origen
df_airport_ranking = df_silver.groupBy(
    "origin_airport"
).agg(
    F.round(
        F.avg(F.col(col_dep_delay)),
        2
    ).alias("avg_delay"),
    F.count("flight_id").alias("total_flights")
)

display(df_airport_ranking)

# COMMAND ----------

# MAGIC %md
# MAGIC Crear columna airport_rank con dense_rank()

# COMMAND ----------

# Crear ventana de ranking
window_airport = Window.orderBy(
    F.col("avg_delay").desc()
)

# Aplicar dense_rank
df_airport_ranking = df_airport_ranking.withColumn(
    "airport_rank",
    F.dense_rank().over(window_airport)
)

# Ordenar resultados
df_airport_ranking = df_airport_ranking.orderBy(
    "airport_rank"
)

display(df_airport_ranking)

# COMMAND ----------

# MAGIC %md
# MAGIC Calcular promedio de retraso, % de vuelos a tiempo, número total de vuelos agrupados por aerolínea y mes

# COMMAND ----------

# Agrupar por aerolínea y mes
df_airline_month = df_temporal.groupBy(
    "airline_id",
    "airline_name",
    "month"
).agg(
    F.round(
        F.avg("delay_total"),
        2
    ).alias("avg_delay"),

    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("on_time_percentage"),

    F.count("flight_id").alias("total_flights")
)

# Ordenar resultados
df_airline_month = df_airline_month.orderBy(
    "airline_name",
    "month"
)

display(df_airline_month)

# COMMAND ----------

# MAGIC %md
# MAGIC Guardar resultados en Delta Lake

# COMMAND ----------

spark.sql("""
CREATE SCHEMA IF NOT EXISTS analitica.gold
""")

# COMMAND ----------

# 1. Análisis de retrasos por mes
df_delay_month.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.delay_by_month")


# 2. Análisis de retrasos por día de la semana
df_delay_weekday.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.delay_by_weekday")


# 3. Análisis de retrasos por trimestre
df_delay_quarter.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.delay_by_quarter")


# 4. Ranking de vuelos con row_number
df_top5_row_number.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.top5_flights_row_number")


# 5. Ranking de vuelos con dense_rank
df_top5_dense_rank.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.top5_flights_dense_rank")


# 6. Ranking de aeropuertos
df_airport_ranking.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.airport_ranking")


# 7. Métricas por aerolínea y mes
df_airline_month.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.airline_month_metrics")

print("¡Análisis avanzado guardado correctamente en Gold!")

# COMMAND ----------

# MAGIC %md
# MAGIC Crear vistas temporales para Databricks SQL

# COMMAND ----------

df_delay_month.createOrReplaceTempView("vw_delay_month")

df_delay_weekday.createOrReplaceTempView("vw_delay_weekday")

df_delay_quarter.createOrReplaceTempView("vw_delay_quarter")

df_top5_row_number.createOrReplaceTempView("vw_top5_flights")

df_airport_ranking.createOrReplaceTempView("vw_airport_ranking")

df_airline_month.createOrReplaceTempView("vw_airline_month")

print("¡Vistas temporales creadas correctamente!")