# Databricks notebook source
# MAGIC %md
# MAGIC ##Cargar los datos de Silver

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Cargar datos de Silver
df_silver = spark.table("analitica.silver.flights_enriched")

# Revisar estructura
df_silver.printSchema()

# Visualizar datos
display(df_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC Extraemos el mes y el año para realizar los análisis temporales:

# COMMAND ----------

df_gold_base = df_silver \
    .withColumn("month", F.month("flight_date")) \
    .withColumn("year", F.year("flight_date"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Crear tablas agregadas Gold

# COMMAND ----------

# MAGIC %md
# MAGIC Retraso promedio por aerolínea y aeropuerto por mes

# COMMAND ----------

df_delay_airline_airport_month = df_gold_base.groupBy(
    "airline_id",
    "airline_name",
    "origin_airport",
    "year",
    "month"
).agg(
    F.round(
        F.avg("delay_total"), 2
    ).alias("avg_delay"),

    F.count("flight_id").alias("total_flights"),

    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("on_time_percentage"),

    F.round(
        F.sum("distance_km"), 2
    ).alias("total_distance_km")
)

display(df_delay_airline_airport_month)

# COMMAND ----------

# MAGIC %md
# MAGIC Ranking de aeropuertos más puntuales

# COMMAND ----------

df_airport_punctuality = df_gold_base.groupBy(
    "origin_airport"
).agg(
    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("punctuality_percentage"),

    F.round(
        F.avg("delay_total"), 2
    ).alias("avg_delay"),

    F.count("flight_id").alias("total_flights")
)

# COMMAND ----------

# MAGIC %md
# MAGIC creamos el ranking utilizando dense_rank

# COMMAND ----------

# Crear ventana para ordenar aeropuertos
window_punctuality = Window.orderBy(
    F.col("punctuality_percentage").desc()
)

# Crear ranking
df_airport_punctuality = df_airport_punctuality.withColumn(
    "airport_rank",
    F.dense_rank().over(window_punctuality)
)

# Ordenar resultados
df_airport_punctuality = df_airport_punctuality.orderBy(
    "airport_rank"
)

display(df_airport_punctuality)

# COMMAND ----------

# MAGIC %md
# MAGIC KPI de porcentaje de vuelos a tiempo por aerolínea

# COMMAND ----------

df_airline_kpi = df_gold_base.groupBy(
    "airline_id",
    "airline_name"
).agg(
    F.count("flight_id").alias("total_flights"),

    F.sum(
        F.when(F.col("on_time") == True, 1).otherwise(0)
    ).alias("on_time_flights"),

    F.sum(
        F.when(F.col("on_time") == False, 1).otherwise(0)
    ).alias("delayed_flights"),

    F.round(
        F.avg(F.col("on_time").cast("double")) * 100,
        2
    ).alias("punctuality_percentage"),

    F.round(
        F.avg("delay_total"), 2
    ).alias("avg_delay"),

    F.round(
        F.sum("distance_km"), 2
    ).alias("total_distance_km")
)

display(df_airline_kpi)

# COMMAND ----------

# MAGIC %md
# MAGIC Guardar las tablas agregadas en Gold

# COMMAND ----------

# Crear esquema Gold
spark.sql("""
CREATE SCHEMA IF NOT EXISTS analitica.gold
""")

# Guardar retrasos por aerolínea, aeropuerto y mes
df_delay_airline_airport_month.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.delay_airline_airport_month")

# Guardar ranking de puntualidad de aeropuertos
df_airport_punctuality.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.airport_punctuality")

# Guardar KPI por aerolínea
df_airline_kpi.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.airline_kpi")

print("¡Tablas Gold almacenadas correctamente!")

# COMMAND ----------

# MAGIC %md
# MAGIC Aplicar optimización Delta Lake

# COMMAND ----------

# DBTITLE 1,Optimizar tablas Gold
# Optimizar tabla de retrasos por aerolínea, aeropuerto y mes
spark.sql("""
OPTIMIZE analitica.gold.delay_airline_airport_month
ZORDER BY (airline_id, origin_airport, month)
""")

# Optimizar tabla de puntualidad de aeropuertos
spark.sql("""
OPTIMIZE analitica.gold.airport_punctuality
ZORDER BY (origin_airport)
""")

# Optimizar tabla de indicadores KPI por aerolínea
spark.sql("""
OPTIMIZE analitica.gold.airline_kpi
ZORDER BY (airline_id)
""")

print("Optimización Delta finalizada correctamente.")

# COMMAND ----------

# DBTITLE 1,Actualizar estadísticas de tablas Gold
tablas = [
    "analitica.gold.delay_airline_airport_month",
    "analitica.gold.airport_punctuality",
    "analitica.gold.airline_kpi"
]

for tabla in tablas:
    spark.sql(f"ANALYZE TABLE {tabla} COMPUTE STATISTICS")

print("Estadísticas actualizadas correctamente.")