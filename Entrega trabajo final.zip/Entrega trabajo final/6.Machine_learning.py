# Databricks notebook source
# MAGIC %md
# MAGIC ##Machine Learning 

# COMMAND ----------

# MAGIC %md
# MAGIC Carga de datos 

# COMMAND ----------

from pyspark.sql import functions as F

# Cargar datos de Silver
df = spark.table("analitica.silver.flights_enriched")

# Identificar la variable objetivo
if "arrival_delay" in df.columns:
    target = "arrival_delay"
elif "arr_delay" in df.columns:
    target = "arr_delay"
else:
    raise Exception("No se encontró la columna de retraso de llegada")

# Variables disponibles
columnas = [
    c for c in [
        "flight_id",
        "flight_date",
        "airline_id",
        "origin_airport",
        "destination_airport",
        "distance_km",
        target
    ]
    if c in df.columns
]

# Preparar dataset
df_gold_ml = df.select(*columnas)

# Convertir variables
df_gold_ml = df_gold_ml.withColumn(
    target, F.col(target).cast("double")
)

if "distance_km" in df_gold_ml.columns:
    df_gold_ml = df_gold_ml.withColumn(
        "distance_km",
        F.col("distance_km").cast("double")
    )

# Eliminar registros sin variable objetivo
df_gold_ml = df_gold_ml.filter(F.col(target).isNotNull())

# Crear variables temporales
if "flight_date" in df_gold_ml.columns:
    df_gold_ml = (
        df_gold_ml
        .withColumn("flight_date", F.to_date("flight_date"))
        .withColumn("month", F.month("flight_date"))
        .withColumn("day_of_week", F.dayofweek("flight_date"))
    )

# Guardar tabla Gold
df_gold_ml.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.flights_model")

display(df_gold_ml)

# COMMAND ----------

# MAGIC %md
# MAGIC Carga de bibliotecas

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import sklearn
import joblib
import mlflow
from sklearn.dummy import DummyRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error

mlflow.autolog(disable=True)
print("scikit-learn:", sklearn.__version__)
print("MLflow:", mlflow.__version__)

# COMMAND ----------

# MAGIC %md
# MAGIC Seleccion de variables para el modelo

# COMMAND ----------

# Cargar tabla Gold
df_model = spark.table("analitica.gold.flights_model")

# Variables categóricas
categorical_cols = [
    c for c in [
        "airline_id",
        "origin_airport",
        "destination_airport"
    ]
    if c in df_model.columns
]

# Variables numéricas
numeric_cols = [
    c for c in [
        "distance_km",
        "month",
        "day_of_week"
    ]
    if c in df_model.columns
]

# Convertir variables categóricas a texto
for c in categorical_cols:
    df_model = df_model.withColumn(c, F.col(c).cast("string"))

# Eliminar registros sin datos predictivos
for c in categorical_cols + numeric_cols:
    df_model = df_model.filter(F.col(c).isNotNull())

print("Variables categóricas:", categorical_cols)
print("Variables numéricas:", numeric_cols)
print("Total de registros:", df_model.count())

display(df_model)

# COMMAND ----------

# MAGIC %md
# MAGIC Datos de entrenamiento y evaluacion 

# COMMAND ----------

# División de datos
train_df, test_df = df_model.randomSplit(
    [0.8, 0.2],
    seed=42
)

print("Datos de entrenamiento:", train_df.count())
print("Datos de evaluación:", test_df.count())

# COMMAND ----------

# MAGIC %md
# MAGIC Entrenamiento del modelo de referencia basado en el promedio 

# COMMAND ----------

from pyspark.sql.functions import avg

# Calcular promedio de retraso
promedio_retraso = train_df.select(
    avg(target)
).first()[0]

# Generar predicciones
baseline_predictions = test_df.withColumn(
    "prediction",
    F.lit(float(promedio_retraso))
)

print("Promedio de retraso:", promedio_retraso)

display(
    baseline_predictions.select(
        target,
        "prediction"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC Entrenamiento del arbol de regresion 

# COMMAND ----------

from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, VectorAssembler, Imputer
from pyspark.ml.regression import DecisionTreeRegressor

# Preparar imputación de variables numéricas
stages = []
input_numeric = []

if numeric_cols:
    imputer = Imputer(
        inputCols=numeric_cols,
        outputCols=[c + "_imputed" for c in numeric_cols]
    )

    stages.append(imputer)
    input_numeric = [c + "_imputed" for c in numeric_cols]

# Codificar variables categóricas
indexed_cols = []

for c in categorical_cols:
    indexer = StringIndexer(
        inputCol=c,
        outputCol=c + "_index",
        handleInvalid="keep"
    )
    stages.append(indexer)
    indexed_cols.append(c + "_index")

# Construir vector de características
assembler = VectorAssembler(
    inputCols=input_numeric + indexed_cols,
    outputCol="features",
    handleInvalid="keep"
)

stages.append(assembler)

# Árbol de regresión
tree = DecisionTreeRegressor(
    featuresCol="features",
    labelCol=target,
    predictionCol="prediction",
    maxDepth=5,
    seed=42
)

stages.append(tree)

# Crear pipeline
pipeline = Pipeline(stages=stages)

# Entrenar modelo
modelo_arbol = pipeline.fit(train_df)

# Generar predicciones
predicciones = modelo_arbol.transform(test_df)

display(
    predicciones.select(
        target,
        "prediction"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC Evaluacion de resultados con MAE Y RMSE 

# COMMAND ----------

from pyspark.ml.evaluation import RegressionEvaluator

# Evaluadores
evaluator_mae = RegressionEvaluator(
    labelCol=target,
    predictionCol="prediction",
    metricName="mae"
)

evaluator_rmse = RegressionEvaluator(
    labelCol=target,
    predictionCol="prediction",
    metricName="rmse"
)

# Métricas del modelo de referencia
mae_baseline = evaluator_mae.evaluate(baseline_predictions)
rmse_baseline = evaluator_rmse.evaluate(baseline_predictions)

# Métricas del árbol
mae_arbol = evaluator_mae.evaluate(predicciones)
rmse_arbol = evaluator_rmse.evaluate(predicciones)

# Comparación
resultados = spark.createDataFrame([
    ("Modelo promedio", float(mae_baseline), float(rmse_baseline)),
    ("Árbol de regresión", float(mae_arbol), float(rmse_arbol))
], ["Modelo", "MAE", "RMSE"])

display(resultados)

# COMMAND ----------

# MAGIC %md
# MAGIC Visualizacion de predicciones frente a valores reales 

# COMMAND ----------

import matplotlib.pyplot as plt

# Tomar una muestra para visualizar
df_grafico = predicciones.select(
    target,
    "prediction"
).limit(500).toPandas()

# Gráfico
plt.figure(figsize=(10, 6))

plt.scatter(
    df_grafico[target],
    df_grafico["prediction"],
    alpha=0.5
)

# Línea de predicción perfecta
minimo = min(
    df_grafico[target].min(),
    df_grafico["prediction"].min()
)

maximo = max(
    df_grafico[target].max(),
    df_grafico["prediction"].max()
)

plt.plot(
    [minimo, maximo],
    [minimo, maximo],
    linestyle="--"
)

plt.xlabel("Retraso real (minutos)")
plt.ylabel("Retraso predicho (minutos)")
plt.title("Predicciones vs valores reales - Retraso de vuelos")
plt.grid(True)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Guardar el modelo las predicciones y las metricas 

# COMMAND ----------

# Guardar predicciones
df_predicciones_final = predicciones.select(
    *(
        ["flight_id"] if "flight_id" in predicciones.columns else []
    ),
    target,
    "prediction"
).withColumn(
    "error",
    F.abs(F.col(target) - F.col("prediction"))
)

df_predicciones_final.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.flight_delay_predictions")

display(df_predicciones_final)

# COMMAND ----------

# Guardar resultados de evaluación
resultados.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.flight_delay_metrics")

display(
    spark.table("analitica.gold.flight_delay_metrics")
)

# COMMAND ----------

# MAGIC %md
# MAGIC Registro del MLFLOW

# COMMAND ----------

# REGISTRO DEL EXPERIMENTO EN MLFLOW

import mlflow
import mlflow.spark

# Nombre del experimento
mlflow.set_experiment("/Shared/Prediccion_Retraso_Vuelos")

# Iniciar registro
with mlflow.start_run(run_name="Arbol_Regresion_Vuelos") as run:

    # Registrar parámetros
    mlflow.log_param("modelo", "DecisionTreeRegressor")
    mlflow.log_param("maxDepth", 5)
    mlflow.log_param("seed", 42)
    mlflow.log_param("variable_objetivo", target)

    mlflow.log_param("variables_numericas", str(numeric_cols))
    mlflow.log_param("variables_categoricas", str(categorical_cols))

    mlflow.log_param("proporcion_entrenamiento", 0.8)
    mlflow.log_param("proporcion_evaluacion", 0.2)

    # Registrar métricas del modelo de referencia
    mlflow.log_metric("MAE_baseline", float(mae_baseline))
    mlflow.log_metric("RMSE_baseline", float(rmse_baseline))

    # Registrar métricas del árbol de regresión
    mlflow.log_metric("MAE_arbol", float(mae_arbol))
    mlflow.log_metric("RMSE_arbol", float(rmse_arbol))

    # Registrar el modelo entrenado
    mlflow.spark.log_model(
        spark_model=modelo_arbol,
        artifact_path="modelo_arbol",
        dfs_tmpdir="/Volumes/analitica/data/landing/mlflow_tmp"
    )

    # Identificador del experimento
    print("Registro MLflow exitoso")
    print("Run ID:", run.info.run_id)
    print("Experiment ID:", run.info.experiment_id)

# COMMAND ----------

# MAGIC %md
# MAGIC Publicacion de metricas como tablas 

# COMMAND ----------

from pyspark.sql import functions as F

# Crear tabla con las métricas de evaluación
metricas_data = [
    ("Baseline", "MAE", float(mae_baseline)),
    ("Baseline", "RMSE", float(rmse_baseline)),
    ("Decision Tree", "MAE", float(mae_arbol)),
    ("Decision Tree", "RMSE", float(rmse_arbol))
]

columnas = ["modelo", "metrica", "valor"]

df_metricas = spark.createDataFrame(metricas_data, columnas)

# Agregar fecha de registro
df_metricas = df_metricas.withColumn(
    "fecha_registro", F.current_timestamp()
)

# Publicar como tabla Delta
df_metricas.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.flight_delay_metrics")

display(df_metricas)

# COMMAND ----------

# MAGIC %md
# MAGIC Publicacion detalles de evaluacion 

# COMMAND ----------

from pyspark.sql import functions as F

# Detalles de evaluación del modelo de referencia
detalle_baseline = baseline_predictions.select(
    *(["flight_id"] if "flight_id" in baseline_predictions.columns else []),
    F.lit("Modelo promedio").alias("modelo"),
    F.col(target).alias("valor_real"),
    F.col("prediction").alias("valor_predicho")
)

# Detalles de evaluación del árbol de regresión
detalle_arbol = predicciones.select(
    *(["flight_id"] if "flight_id" in predicciones.columns else []),
    F.lit("Árbol de regresión").alias("modelo"),
    F.col(target).alias("valor_real"),
    F.col("prediction").alias("valor_predicho")
)

# Unir los resultados de ambos modelos
df_detalles_evaluacion = detalle_baseline.unionByName(detalle_arbol)

# Calcular errores
df_detalles_evaluacion = (
    df_detalles_evaluacion
    .withColumn(
        "error_absoluto",
        F.abs(F.col("valor_real") - F.col("valor_predicho"))
    )
    .withColumn(
        "error_cuadrado",
        F.pow(F.col("valor_real") - F.col("valor_predicho"), 2)
    )
)

# Publicar tabla Delta
df_detalles_evaluacion.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("analitica.gold.flight_delay_evaluation_details")

# Visualizar resultados
display(df_detalles_evaluacion)

# COMMAND ----------

# MAGIC %md
# MAGIC Comprobaciones en SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM analitica.gold.flight_delay_predictions
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     modelo,
# MAGIC     COUNT(*) AS total_vuelos,
# MAGIC     ROUND(AVG(error_absoluto), 2) AS error_absoluto_promedio,
# MAGIC     ROUND(SQRT(AVG(error_cuadrado)), 2) AS RMSE
# MAGIC FROM analitica.gold.flight_delay_evaluation_details
# MAGIC GROUP BY modelo;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     COUNT(*) AS total_predicciones,
# MAGIC     COUNT(DISTINCT flight_id) AS vuelos_unicos,
# MAGIC     ROUND(AVG(error), 2) AS mae_arbol_minutos
# MAGIC FROM analitica.gold.flight_delay_predictions;